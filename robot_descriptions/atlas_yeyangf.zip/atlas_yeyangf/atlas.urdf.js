darkgray = [.2, .2, .2, 1];
sawyer_red = [.5, .1, .1, 1];
darkred = sawyer_red;
sawyer_gray = [0.75294, 0.75294, 0.75294, 1];


robot = {
  name:"atlas", 
  base:"pelvis", 
  origin:{ xyz: [0,1,0], rpy:[0,0,0] },
  links: {
    "head": { 
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry: { mesh: { filename: "meshes/head.dae" } },
      }
      },

      "l_clav": {
          visual: {
              origin: { xyz: [0, 0.048, -0.084], rpy: [0, 0, 0] },
              geometry: { mesh: { filename: "meshes/l_clav.dae" } },
          }
      },

    "l_foot": {
      visual : { 
          origin: { xyz: [0.027,0,-0.067], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_foot.dae" } },
      }
      },

    /*"l_hand": { 
      visual : { 
        origin : { xyz: [0,0.06,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_hand.dae" } },
      }
    },*/
    "l_lfarm": {
      visual : { 
        origin : { xyz: [0,-0.07,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_hand.dae" } },
      }
    },
    
    "l_larm": { 
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_larm.dae" } },         
      }
      },

    "l_lglut": { 
      visual : { 
          origin: { xyz: [0.0133341, 0.0170484, -0.0312052], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_lglut.dae" } },        
      }
      },

    "l_lleg": { 
      visual : { 
        origin : { xyz: [0,0,-0.187], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_lleg.dae" } },        
      }
      },

    "l_scap": { 
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_scap.dae" } },
        
      }
      },

    "l_talus": { 
      visual : { 
          origin: { xyz: [0,0,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_talus.dae" } },        
      }
      },

    "l_uarm": { 
      visual : { 
        origin : { xyz: [0,-0.065,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_uarm.dae" } },        
      }
      },

    "l_ufarm": { 
      visual : { 
        origin : { xyz: [0,-0.2,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_farm.dae" } },
      }
      },

    "l_uglut": { 
      visual : { 
        origin : { xyz: [0.0053,-0.0034,0.0031], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_uglut.dae" } },         
      }
    },

    "l_uleg": { 
      visual : { 
          origin: { xyz: [0,0,-0.21], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/l_uleg.dae" } },         
      }
    },

    "ltorso": { 
      visual : { 
        origin : { xyz: [-0.011,0,0.0747], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/ltorso.dae" } },        
      }
      },

    "mtorso": { 
      visual : { 
        origin : { xyz: [-0.0082,-0.0131,0.0306], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/mtorso.dae" } },        
      }
      },

    "pelvis": { 
      visual : { 
          origin: { xyz: [0.0111,0,0.0271], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/pelvis.dae" } },        
      }
      },

    "r_clav": { 
      visual : { 
          origin: { xyz: [0 ,-0.048, -0.084], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_clav.dae" } },        
      }
      },

    "r_foot": { 
      visual : { 
        origin : { xyz: [0.027,0,-0.067], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_foot.dae" } },         
      }
      },

   /*"r_hand": { 
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_hand.dae" } },        
      }
    },*/

    "r_larm": { 
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_larm.dae" } }, 
      }
      },

    "r_lfarm": { 
      visual : { 
        origin : { xyz: [0,0.07,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_hand.dae" } },        
      }
    },
    
    "r_lglut": { 
      visual : { 
          origin: { xyz: [0.013331,-0.01705,-0.031205], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_lglut.dae" } },         
      }
      },

    "r_lleg": { 
      visual : { 
        origin : { xyz: [0.001,0,-0.187], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_lleg.dae" } },         
      }
      },

    "r_scap": { 
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_scap.dae" } },
         
      }
      },
    "r_talus": { 
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_talus.dae" } },
         
      }
      },
    "r_uarm": { 
      visual : { 
        origin : { xyz: [0,0.065,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_uarm.dae" } },        
      }
      },

    "r_ufarm": { 
      visual : { 
        origin : { xyz: [0,0.2,0], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_farm.dae" } },
         
      }
      },
    "r_uglut": { 
      visual : { 
        origin : { xyz: [0.0053,0.0034,0.0031], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_uglut.dae" } },         
      }
      },

    "r_uleg": { 
      visual : { 
          origin: { xyz: [0,0,-0.21], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/r_uleg.dae" } },         
      }
      },

    "utorso": { 
      visual : { 
        origin : { xyz: [-0.0581,0,0.3056], rpy:[0,0,0] },
          geometry: { mesh: { filename: "meshes/utorso.dae" } },  
      }
      }, 
  },

};


// specify name of endeffector frame
robot.endeffector = {};
robot.endeffector.frame = "l_arm_wrx";
robot.endeffector.position = [[0.1], [0], [0], [1]];

robot.joints = {};

// hacked origin offset for pedestal base
robot.joints.back_bkx = {
    type: "revolute",
    parent: "mtorso", child: "utorso",
    axis: [1, 0, 0],
    origin: { xyz: [0, 0, 0.05], rpy: [0, 0, 0]},
    limit: { lower: -0.523599, upper: 0.523599}
};

robot.joints.back_bky = { 
    type : "revolute",
    parent: "ltorso", child: "mtorso",
    axis : [0,1,0],
    origin : {xyz: [0,0,0.162], rpy:[0,0,0]},
    limit: { lower: -0.219388, upper: 0.538783}
};

robot.joints.back_bkz = { 
    type: "revolute",
    parent: "pelvis", child: "ltorso",
    axis : [0,0,1],
    origin: { xyz: [-0.0125, 0, 0], rpy:[0,0,0]},
    limit : {lower:-0.663225, upper:0.663225}
};

robot.joints.l_arm_elx = {
    type: "revolute",
    parent: "l_uarm", child: "l_larm",
    axis: [1, 0, 0],
    origin: { xyz: [0,0.119,0.0092], rpy: [0, 0, 0] },
    limit: { lower: 0, upper: 2.35619 }
};

robot.joints.l_arm_ely = {
    type: "revolute",
    parent: "l_scap", child: "l_uarm",
    axis: [0, 1, 0],
    origin: { xyz: [0,0.187,-0.016], rpy: [0, 0, 0] },
    limit: { lower: 0, upper: 3.14159 }
};

robot.joints.l_arm_shx = {
    type: "revolute",
    parent: "l_clav", child: "l_scap",
    axis: [1,0,0 ],
    origin: { xyz: [0,0.11,-0.245], rpy: [0, 0, 0] },
    limit: { lower:-1.5708 , upper:1.5708  }
};

robot.joints.l_arm_shz = {
    type: "revolute",
    parent: "utorso", child: "l_clav",
    axis: [0,0 ,1],
    origin: { xyz: [0.1406, 0.2256, 0.4776], rpy: [0, 0, 0] },
    limit: { lower: -1.5708, upper: 0.785398  }
};

robot.joints.l_arm_wrx = {
    type: "revolute",
    parent: "l_ufarm", child: "l_lfarm",
    axis: [1,0 ,0],
    origin: { xyz: [0, 0, 0], rpy: [0, 0, 0] },
    limit: { lower: -1.7628, upper: 1.7628 }
};

robot.joints.l_arm_wry = {
    type: "revolute",
    parent: "l_larm", child: "l_ufarm",
    axis: [0,1,0],
    origin: { xyz: [0,0.29955,-0.00921], rpy: [0, 0, 0] },
    limit: { lower:-3.011, upper: 3.011  }
};
/*
robot.joints.l_arm_wry2 = {
    type: "revolute",
    parent: "l_lfarm", child: "l_hand",
    axis: [0, 1, 0],
    origin: { xyz: [0, 0, 0], rpy: [0, 0, 0] },
    limit: { lower: -2.9671, upper: 2.9671 }
};*/

robot.joints.l_leg_akx = {
    type: "revolute",
    parent: "l_talus", child: "l_foot",
    axis: [1,0 ,0],
    origin: { xyz: [0,0 ,0], rpy: [0, 0, 0] },
    limit: { lower: -0.8, upper:0.8  }
};

robot.joints.l_leg_aky = {
    type: "revolute",
    parent: "l_lleg", child: "l_talus",
    axis: [0,1 ,0],
    origin: { xyz: [0,0 ,-0.422], rpy: [0, 0, 0] },
    limit: { lower:-1 , upper:0.7  }
};

robot.joints.l_leg_hpx = {
    type: "revolute",
    parent: "l_uglut", child: "l_lglut",
    axis: [1,0 ,0],
    origin: { xyz: [0,0, 0], rpy: [0, 0, 0] },
    limit: { lower: -0.523599, upper: 0.523599 }
};

robot.joints.l_leg_hpy = {
    type: "revolute",
    parent: "l_lglut", child: "l_uleg",
    axis: [0,1 ,0],
    origin: { xyz: [0.05, 0.0225,-0.066], rpy: [0, 0, 0] },
    limit: { lower: -1.61234, upper: 0.65764  }
};

robot.joints.l_leg_hpz = {
    type: "revolute",
    parent: "pelvis", child: "l_uglut",
    axis: [0,0 ,1],
    origin: { xyz: [0,0.089 ,0], rpy: [0, 0, 0] },
    limit: { lower: -0.174358, upper: 0.786794  }
};

robot.joints.l_leg_kny = {
    type: "revolute",
    parent: "l_uleg", child: "l_lleg",
    axis: [0,1,0],
    origin: { xyz: [-0.05, 0,-0.374], rpy: [0, 0, 0] },
    limit: { lower:0 , upper: 2.35637  }
};

robot.joints.neck_ry = {
    type: "revolute",
    parent: "utorso", child: "head",
    axis: [0,1 ,0],
    origin: { xyz: [0.2546, 0, 0.6215], rpy: [0, 0, 0] },
    limit: { lower: -0.602139, upper: 1.14319  }
};

robot.joints.r_arm_elx = {
    type: "revolute",
    parent: "r_uarm", child: "r_larm",
    axis: [1,0 ,0],
    origin: { xyz: [0, -0.119, 0.0092], rpy: [0, 0, 0] },
    limit: { lower: -2.35619, upper:0  }
};

robot.joints.r_arm_ely = {
    type: "revolute",
    parent: "r_scap", child: "r_uarm",
    axis: [0, 1,0],
    origin: {xyz: [0, -0.187, 0.016], rpy: [0, 0, 0] },
    limit: { lower: 0, upper: 3.14159 }
};

robot.joints.r_arm_shx = {
    type: "revolute",
    parent: "r_clav", child: "r_scap",
    axis: [1,0 ,0],
    origin: { xyz: [0, - 0.11, -0.245], rpy: [0, 0, 0] },
    limit: { lower: -1.5708, upper: 1.5708  }
};

robot.joints.r_arm_shz = {
    type: "revolute",
    parent: "utorso", child: "r_clav",
    axis: [0,0 ,1],
    origin: { xyz: [0.1406, -0.2256, 0.4776], rpy: [0, 0, 0] },
    limit: { lower: -0.785398, upper: 1.5708  }
};

robot.joints.r_arm_wrx = {
    type: "revolute",
    parent: "r_ufarm", child: "r_lfarm",
    axis: [1,0 ,0],
    origin: { xyz: [0,0,0], rpy: [0, 0, 0] },
    limit: { lower: -1.7628, upper: 1.7628  }
};

robot.joints.r_arm_wry = {
    type: "revolute",
    parent: "r_larm", child: "r_ufarm",
    axis: [0,1 ,0],
    origin: { xyz: [0,-0.29955,-0.00921], rpy: [0, 0, 0] },
    limit: { lower: -3.011, upper: 3.011  }
};

robot.joints.r_leg_akx = {
    type: "revolute",
    parent: "r_talus", child: "r_foot",
    axis: [1,0 ,0],
    origin: { xyz: [0,0 ,0], rpy: [0, 0, 0] },
    limit: { lower: -0.8, upper: 0.8 }
};

robot.joints.r_leg_aky = {
    type: "revolute",
    parent: "r_lleg", child: "r_talus",
    axis: [0,1 ,0],
    origin: { xyz: [0, 0, -0.422], rpy: [0, 0, 0] },
    limit: { lower:-1 , upper:0.7  }
};

robot.joints.r_leg_hpx = {
    type: "revolute",
    parent: "r_uglut", child: "r_lglut",
    axis: [1,0 ,0],
    origin: { xyz: [0,0,0], rpy: [0, 0, 0] },
    limit: { lower: -0.523599, upper: 0.523599 }
};

robot.joints.r_leg_hpy = {
    type: "revolute",
    parent: "r_lglut", child: "r_uleg",
    axis: [0, 1,0],
    origin: { xyz: [0.05, -0.0225, -0.066], rpy: [0, 0, 0] },
    limit: { lower: -1.61234, upper: 0.65764  }
};

robot.joints.r_leg_hpz = {
    type: "revolute",
    parent: "pelvis", child: "r_uglut",
    axis: [0, 0,1],
    origin: { xyz: [0,-0.089 ,0], rpy: [0, 0, 0] },
    limit: { lower: -0.786794, upper: 0.174358  }
};

robot.joints.r_leg_kny = {
    type: "revolute",
    parent: "r_uleg", child: "r_lleg",
    axis: [0,1 ,0],
    origin: { xyz: [-0.05, 0, -0.374], rpy: [0, 0, 0] },
    limit: { lower:0 , upper: 2.35637  }
};




// note ROS coordinate system (x:forward, y:lateral, z:up) is different than threejs (x:lateral, y:up, z:forward)
robot.links_geom_imported = true;

links_geom = {};

// KE: replace hardcoded robot directory
// KE: replace file extension processing
i = 0;
for (x in robot.links) {
    //geom_index = robot.links[x].visual.geometry.mesh.filename.split('_adjusted')[0];
    //geom_extension = robot.links[x].visual.geometry.mesh.filename.split('_adjusted')[1];
    filename_split = robot.links[x].visual.geometry.mesh.filename.split('.');
    geom_index = filename_split[0];
    geom_extension = filename_split[filename_split.length - 1];
    console.log(geom_index + "  " + geom_extension);
    
    if (geom_extension === "dae") { // extend to use regex
        assignFetchModelCollada('./robots/atlas/' + robot.links[x].visual.geometry.mesh.filename, x);
    }
    else if (geom_extension === "DAE") { // extend to use regex
        assignFetchModelCollada('./robots/atlas/' + robot.links[x].visual.geometry.mesh.filename, x);
    }
    else {
        assignFetchModelSTL('./robots/atlas/' + robot.links[x].visual.geometry.mesh.filename, robot.links[x].visual.material, x);
    }
    i++;
}

function assignFetchModelCollada(filename, index) {

    console.log("assignFetchModel : " + filename + " - " + index);
    var collada_loader = new THREE.ColladaLoader();
    var val = collada_loader.load(filename,
        function (collada) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename + " - " + index + ": " + (xhr.loaded / xhr.total * 100) + '% loaded');
        }
    );
}

function assignFetchModelCollada2(filename, index) {

    console.log("assignFetchModel : " + filename + " - " + index);
    var collada_loader = new ColladaLoader2();
    var val = collada_loader.load(filename,
        function (collada) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename + " - " + index + ": " + (xhr.loaded / xhr.total * 100) + '% loaded');
        }
    );
}


function assignFetchModelSTL(filename, material_urdf, linkname) {

    console.log("assignFetchModel : " + filename + " - " + linkname);
    var stl_loader = new THREE.STLLoader();
    var val = stl_loader.load(filename,
        function (geometry) {
            // ocj: add transparency
            var material_color = new THREE.Color(material_urdf.color.rgba[0], material_urdf.color.rgba[1], material_urdf.color.rgba[2]);
            var material = new THREE.MeshLambertMaterial({ color: material_color, side: THREE.DoubleSide });
            links_geom[linkname] = new THREE.Mesh(geometry, material);
        } //,
        //function (xhr) {
        //    console.log(filename+" - "+linkname+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        //}
    );
}