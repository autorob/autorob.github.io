
grey = [.2,.2,.2,1];
orange = [1,.42,.039,1];
Blue = [0.5,0.7,1,1]; 

robot = {
  name:"lbr_iiwa", 
  base:"lbr_iiwa_link_0", 
  //base:"right_arm_base_link", 
  //origin:{ xyz: [0,0.1,0], rpy:[0,0,0] },
  origin:{ xyz: [0.0,0,0.0], rpy:[0,0,0] },

  links: {
/*
    "base": {}, // empty link
    "torso": { // no geometry
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "r_wheel_link.STL" } },
          // box 0 0 0
        material : { color : { rgba : [0.086, 0.506, 0.767, 1] } }
          // rgba .2 .2 .2 1
      }
    },
*/
    "lbr_iiwa_link_0": {
      visual : { 
        //origin : { xyz: [0.26,0.345,-0.91488], rpy:[1.57079632679,0,-1.57079632679] },
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        //geometry : { mesh : { filename : "sawyer_pv/pedestal.DAE" } },
        geometry : { mesh : { filename : "meshes/link_0.stl" } },
        material : { color : { rgba : grey } }
      }
    },
/*
    "controller_box": { //collision only
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "r_wheel_link.STL" } },
        material : { color : { rgba : [0.086, 0.506, 0.767, 1] } }
      }
    },
    "pedestal_feet": { // collision only
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "r_wheel_link.STL" } },
        material : { color : { rgba : [0.086, 0.506, 0.767, 1] } }
      }
    },
*/
    "lbr_iiwa_link_1": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "meshes/link_1.stl" } },
        //geometry : { mesh : { filename : "sawyer_pv/base.DAE" } },
        material : { color : { rgba : Blue } }
      }
    },
    "lbr_iiwa_link_2": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        //geometry : { mesh : { filename : "sawyer_mp3/l0.DAE" } },
        geometry : { mesh : { filename : "meshes/link_2.stl" } },
        material : { color : { rgba : [Blue] } }
      }
    },
    "lbr_iiwa_link_3": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        //geometry : { mesh : { filename : "sawyer_mp3/l0.DAE" } },
        geometry : { mesh : { filename : "meshes/link_3.stl" } },
        material : { color : { rgba : [orange] } }
      }
    },
    "lbr_iiwa_link_4": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        //geometry : { mesh : { filename : "sawyer_mp3/l0.DAE" } },
        geometry : { mesh : { filename : "meshes/link_4.stl" } },
        material : { color : { rgba : [Blue] } }
      }
    },
    "lbr_iiwa_link_5": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        //geometry : { mesh : { filename : "sawyer_mp3/l0.DAE" } },
        geometry : { mesh : { filename : "meshes/link_5.stl" } },
        material : { color : { rgba : [Blue] } }
      }
    },
    "lbr_iiwa_link_6": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        //geometry : { mesh : { filename : "sawyer_mp3/l0.DAE" } },
        geometry : { mesh : { filename : "meshes/link_6.stl" } },
        material : { color : { rgba : [orange] } }
      }
    },
    "lbr_iiwa_link_7": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        //geometry : { mesh : { filename : "sawyer_mp3/l0.DAE" } },
        geometry : { mesh : { filename : "meshes/link_6.stl" } },
        material : { color : { rgba : grey } }
      }
    },

  },
 
};

/*
  <joint name="controller_box_fixed" type="fixed">
  <joint name="pedestal_feet_fixed" type="fixed">
  <joint name="torso_t0" type="fixed">
  <joint name="pedestal_fixed" type="fixed">
  <joint name="right_arm_mount" type="fixed">
  <joint name="right_j0" type="revolute">
  <joint name="head_pan" type="revolute">
*/

// specify name of endeffector frame
robot.endeffector = {};
robot.endeffector.frame = "lbr_iiwa_joint_7";
robot.endeffector.position = [[0.1],[0],[0],[1]]

robot.joints = {};
/*
robot.joints.torso_lift_joint = {parent:"base_link", child:"torso_lift_link"};
robot.joints.torso_lift_joint.axis = [0,0,1];
robot.joints.torso_lift_joint.type = "prismatic";
robot.joints.torso_lift_joint.origin = {xyz: [-0.086875,0,0.37743], rpy:[-6.123E-17,0,0]};
robot.joints.torso_lift_joint.limit = {lower:0, upper:0.4};
*/

// hacked origin offset for pedestal base and missing controller box
robot.joints.lbr_iiwa_joint_1 = {parent:"lbr_iiwa_link_0", child:"lbr_iiwa_link_1"};
robot.joints.lbr_iiwa_joint_1.axis = [0,0,1];
robot.joints.lbr_iiwa_joint_1.type = "revolute";
robot.joints.lbr_iiwa_joint_1.origin = {xyz: [0,0,0.1575], rpy:[0,0,0]};
robot.joints.lbr_iiwa_joint_1.limit = {lower:-2.96, upper:2.96};

robot.joints.lbr_iiwa_joint_2 = {parent:"lbr_iiwa_link_1", child:"lbr_iiwa_link_2"};
robot.joints.lbr_iiwa_joint_2.axis = [0,0,1];
robot.joints.lbr_iiwa_joint_2.type = "revolute";
robot.joints.lbr_iiwa_joint_2.origin = {xyz:[0,0,0.2025] , rpy:[1.57,0,3.14]};
robot.joints.lbr_iiwa_joint_2.limit = {lower:-2.09, upper:2.09};

robot.joints.lbr_iiwa_joint_3 = {parent:"lbr_iiwa_link_2", child:"lbr_iiwa_link_3"};
robot.joints.lbr_iiwa_joint_3.axis = [0,0,1];
robot.joints.lbr_iiwa_joint_3.type = "revolute";
robot.joints.lbr_iiwa_joint_3.origin = {xyz: [0,0.2045,0], rpy:[1.57,0,3.14]};
robot.joints.lbr_iiwa_joint_3.limit = {lower:-2.09, upper:2.09};

robot.joints.lbr_iiwa_joint_4 = {parent:"lbr_iiwa_link_3", child:"lbr_iiwa_link_4"};
robot.joints.lbr_iiwa_joint_4.axis = [0,0,1];
robot.joints.lbr_iiwa_joint_4.type = "revolute";
robot.joints.lbr_iiwa_joint_4.origin = {xyz: [0,0,0.215], rpy:[1.570,0,0]};
robot.joints.lbr_iiwa_joint_4.limit = {lower:-2.09, upper:2.09};

robot.joints.lbr_iiwa_joint_5 = {parent:"lbr_iiwa_link_4", child:"lbr_iiwa_link_5"};
robot.joints.lbr_iiwa_joint_5.axis = [0,0,1];
robot.joints.lbr_iiwa_joint_5.type = "revolute";
robot.joints.lbr_iiwa_joint_5.origin = {xyz: [0,0.1845,0], rpy:[-1.570,3.1415,0]};
robot.joints.lbr_iiwa_joint_5.limit = {lower:-2.96, upper:2.96};

robot.joints.lbr_iiwa_joint_6 = {parent:"lbr_iiwa_link_5", child:"lbr_iiwa_link_6"};
robot.joints.lbr_iiwa_joint_6.axis = [0,0,1];
robot.joints.lbr_iiwa_joint_6.type = "revolute";
robot.joints.lbr_iiwa_joint_6.origin = {xyz: [0,0,0.2155], rpy:[1.570,0,0]};
robot.joints.lbr_iiwa_joint_6.limit = {lower:-2.09, upper:2.09};

robot.joints.lbr_iiwa_joint_7 = {parent:"lbr_iiwa_link_6", child:"lbr_iiwa_link_7"};
robot.joints.lbr_iiwa_joint_7.axis = [0,0,1];
robot.joints.lbr_iiwa_joint_7.type = "revolute";
robot.joints.lbr_iiwa_joint_7.origin = {xyz: [0,0.081,0], rpy:[-1.570,3.1415,0]};
robot.joints.lbr_iiwa_joint_7.limit = {lower:-3.0543, upper:3.0543};

// note ROS coordinate system (x:forward, y:lateral, z:up) is different than threejs (x:lateral, y:up, z:forward)
robot.links_geom_imported = true;

links_geom = {};

  // KE: replace hardcoded robot directory
  // KE: replace file extension processing
i = 0;
for (x in robot.links) {
  //geom_index = robot.links[x].visual.geometry.mesh.filename.split('_adjusted')[0];
  //geom_extension = robot.links[x].visual.geometry.mesh.filename.split('_adjusted')[1];
  filename_split = robot.links[x].visual.geometry.mesh.filename.split('.');
  geom_index = filename_split[0];
  geom_extension = filename_split[filename_split.length-1];
  console.log(geom_index + "  " + geom_extension);
  //assignFetchModel('./robots/sawyer/'+robot.links[x].visual.geometry.mesh.filename,geom_index);
  if (geom_extension === "dae") { // extend to use regex
    assignFetchModelCollada('./robots/sawyer/'+robot.links[x].visual.geometry.mesh.filename,x);
  }
  else if (geom_extension === "DAE") { // extend to use regex
    assignFetchModelCollada('./robots/sawyer/'+robot.links[x].visual.geometry.mesh.filename,x);
  }
  else {
    assignFetchModelSTL('./robots/lbr_iiwa_92444690/'+robot.links[x].visual.geometry.mesh.filename,robot.links[x].visual.material,x);
  }
  i++;
}

function assignFetchModelCollada(filename,index) {

    console.log("assignFetchModel : "+filename+" - "+index); 
    var collada_loader = new THREE.ColladaLoader();
    var val = collada_loader.load(filename, 
       function ( collada ) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename+" - "+index+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        }
    );
}

function assignFetchModelCollada2(filename,index) {

    console.log("assignFetchModel : "+filename+" - "+index); 
    var collada_loader = new ColladaLoader2();
    var val = collada_loader.load(filename, 
       function ( collada ) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename+" - "+index+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        }
    );
}


function assignFetchModelSTL(filename,material_urdf,linkname) {

    console.log("assignFetchModel : "+filename+" - "+linkname); 
    var stl_loader = new THREE.STLLoader();
    var val = stl_loader.load(filename, 
       function ( geometry ) {
            // ocj: add transparency
            var material_color = new THREE.Color(material_urdf.color.rgba[0], material_urdf.color.rgba[1], material_urdf.color.rgba[2]);
            var material = new THREE.MeshLambertMaterial( {color: material_color, side: THREE.DoubleSide} );
            links_geom[linkname] = new THREE.Mesh( geometry, material ) ;
        } //,
        //function (xhr) {
        //    console.log(filename+" - "+linkname+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        //}
    );
}




