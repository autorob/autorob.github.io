
/*
     Universal Robots UR10 robot URDF kinematic description in JavaScript
     
     @author Chengyang Huang

     based on description and Collada models and Fetch Model from OCJ:

         https://github.com/ros-industrial/universal_robot/blob/kinetic-devel/ur_description/urdf/ur10.urdf.xacro

*/

d1 = 0.1273;
a2 = -0.612;
a3 = -0.5723;
d4 = 0.163941;
d5 = 0.1157;
d6 = 0.0922;

shoulder_offset = 0.220941;
elbow_offset = -0.1719;

shoulder_height = d1;
upper_arm_length = -a2;
forearm_length = -a3;
wrist_1_length = d4 - elbow_offset - shoulder_offset;
wrist_2_length = d5;
wrist_3_length = d6;
console.log(forearm_length);

console.log(wrist_1_length);
console.log(wrist_2_length);
console.log(wrist_3_length);

robot = {
  name:"UR10",
  base:"base_link", 
  origin:{ xyz: [0,0.1,0], rpy:[0,0,0] },
  links: {
    "base_link": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "base.dae" } }
      }
    },
    
    "shoulder_link": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "shoulder.dae" } }
      }
    },
      
    "upper_arm_link": {
      visual : {
          origin : { xyz: [0,0,-a2/2], rpy:[0,0,0] },
          geometry : { mesh : { filename : "upperarm.dae" } }
      }
    },
    
    "forearm_link": {
      visual : {
          origin : { xyz: [0,0,-a3/2], rpy:[0,0,0] },
          geometry : { mesh : { filename : "forearm.dae" } }
      }
    },
      
    "wrist_1_link": {
      visual : {
          origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry : { mesh : { filename : "wrist1.dae" } }
      }
    },
      
    "wrist_2_link": {
      visual : {
          origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry : { mesh : { filename : "wrist2.dae" } }
      }
    },
      
    "wrist_3_link": {
      visual : {
          origin : { xyz: [0,0,0], rpy:[0,0,0] },
          geometry : { mesh : { filename : "wrist3.dae" } }
      }
    },
     
  },
};

// specify name of endeffector frame
robot.endeffector = {};
robot.endeffector.frame = "wrist_3_joint";
robot.endeffector.position = [ [0.1],[0],[0],[1] ]

robot.joints = {};

robot.joints.shoulder_pan_joint = {parent:"base_link", child:"shoulder_link"};
robot.joints.shoulder_pan_joint.axis = [0,0,1];
robot.joints.shoulder_pan_joint.type = "revolute";
robot.joints.shoulder_pan_joint.origin = {xyz: [0,0,shoulder_height], rpy:[0,0,0]};
robot.joints.shoulder_pan_joint.limit = {lower:-Math.PI, upper:Math.PI};

robot.joints.shoulder_lift_joint = {parent:"shoulder_link", child:"upper_arm_link"};
robot.joints.shoulder_lift_joint.axis = [0,1,0];
robot.joints.shoulder_lift_joint.type = "revolute";
robot.joints.shoulder_lift_joint.origin = {xyz: [0,shoulder_offset,0], rpy:[0,Math.PI/6.0,0]};
robot.joints.shoulder_lift_joint.limit = {lower:-Math.PI, upper:Math.PI};

robot.joints.elbow_joint = {parent:"upper_arm_link", child:"forearm_link"};
robot.joints.elbow_joint.axis = [0,1,0];
robot.joints.elbow_joint.type = "revolute";
robot.joints.elbow_joint.origin = {xyz: [0,elbow_offset,upper_arm_length], rpy:[0,Math.PI/6.0,0]};
robot.joints.elbow_joint.limit = {lower:-Math.PI, upper:Math.PI};

robot.joints.wrist_1_joint = {parent:"forearm_link", child:"wrist_1_link"};
robot.joints.wrist_1_joint.axis = [0,1,0];
robot.joints.wrist_1_joint.type = "revolute";
robot.joints.wrist_1_joint.origin = {xyz: [0,0,forearm_length], rpy:[0,Math.PI/2.0,0]};
robot.joints.wrist_1_joint.limit = {lower:-Math.PI, upper:Math.PI};

robot.joints.wrist_2_joint = {parent:"wrist_1_link", child:"wrist_2_link"};
robot.joints.wrist_2_joint.axis = [0,1,0];
robot.joints.wrist_2_joint.type = "revolute";
robot.joints.wrist_2_joint.origin = {xyz: [0,wrist_1_length,0], rpy:[0,0,0]};
robot.joints.wrist_2_joint.limit = {lower:-Math.PI, upper:Math.PI};

robot.joints.wrist_3_joint = {parent:"wrist_2_link", child:"wrist_3_link"};
robot.joints.wrist_3_joint.axis = [0,1,0];
robot.joints.wrist_3_joint.type = "revolute";
robot.joints.wrist_3_joint.origin = {xyz: [0,0,wrist_2_length], rpy:[0,0,0]};
robot.joints.wrist_3_joint.limit = {lower:-Math.PI, upper:Math.PI};


// note ROS coordinate system (x:forward, y:lateral, z:up) is different than threejs (x:lateral, y:up, z:forward)
robot.links_geom_imported = true;

links_geom = {};

  // KE: replace hardcoded robot directory
  // KE: replace file extension processing
progressLinkLoading = 0;
i = 0;
imax = Object.keys(robot.links).length;
for (x in robot.links) {

  filename_split = robot.links[x].visual.geometry.mesh.filename.split('.');
  geom_index = filename_split[0];
  geom_extension = filename_split[filename_split.length-1];
  console.log(geom_index + "  " + geom_extension);
  if (geom_extension === "dae") { // KE: extend to use regex
    assignURModelCollada('./robots/UR10/meshes/ur10/visual/'+robot.links[x].visual.geometry.mesh.filename,x);
  }
    /*
  else if (geom_extension === "DAE") { // extend to use regex
    assignURModelCollada('./robots/UR10/meshes/ur10/visual/'+robot.links[x].visual.geometry.mesh.filename,x);
  }
  else {
    assignURModelSTL('./robots/UR10/meshes/ur10/visual/'+robot.links[x].visual.geometry.mesh.filename,robot.links[x].visual.material,x);
  }
     */
  i++;

  progressLinkLoading = i/imax; 
  console.log("Robot geometry: progressLinkLoading " + progressLinkLoading*100);
}

function assignURModelCollada(filename,index) {

    console.log("assignURModel : "+filename+" - "+index);
    var collada_loader = new THREE.ColladaLoader();
    var val = collada_loader.load(filename, 
       function ( collada ) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename+" - "+index+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        }
    );
}
/*
function assignURModelCollada2(filename,index) {

    console.log("assignURModel : "+filename+" - "+index);
    var collada_loader = new ColladaLoader2();
    var val = collada_loader.load(filename, 
       function ( collada ) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename+" - "+index+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        }
    );
}


function assignURModelSTL(filename,material_urdf,linkname) {

    console.log("assignURModel : "+filename+" - "+linkname);
    var stl_loader = new THREE.STLLoader();
    var val = stl_loader.load(filename, 
       function ( geometry ) {
            // ocj: add transparency
            var material_color = new THREE.Color(material_urdf.color.rgba[0], material_urdf.color.rgba[1], material_urdf.color.rgba[2]);
            var material = new THREE.MeshLambertMaterial( {color: material_color, side: THREE.DoubleSide} );
            links_geom[linkname] = new THREE.Mesh( geometry, material ) ;
        } //,
        //function (xhr) {
        //    console.log(filename+" - "+linkname+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        //}
    );
}
*/
