//////////////////////////////////
///   Custom Robot Definition  ///
//////////////////////////////////

robot = {
  name:"walle", 
  base:"body", 
  origin:{ xyz: [0,0,0], rpy:[0,0,0] },
  links: {
    "body": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "body.STL" } },
	material : { color : {
	    rgba : [.65, .35, .1, 1]
	  }
	}
      }
    },
    "neck": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "neck.STL" } },
	material : { color : {
	    rgba : [.65, .35, .1, 1]
	  }
	}
      }
    },
    "arm_L": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "arm.STL" } },
	material : { color : {
	    rgba : [.4, .4, .4, 1]
	  }
	}
      }
    },
    "arm_R": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "arm.STL" } },
	material : { color : {
	    rgba : [.4, .4, .4, 1]
	  }
	}
      }
    },
    "foot_L": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "foot.STL" } },
	material : { color : {
	    rgba : [.1, .1, .1, 1]
	  }
	}
      }
    },
    "foot_R": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "foot.STL" } },
	material : { color : {
	    rgba : [.1, .1, .1, 1]
	  }
	}
      }
    },
    "hand_L": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "hand.STL" } },
	material : { color : {
	    rgba : [.9, .9, .9, 1]
	  }
	}
      }
    },
    "hand_R": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "hand.STL" } },
	material : { color : {
	    rgba : [.9, .9, .9, 1]
	  }
	}
      }
    },
    "eyes": {
      visual : { 
        origin : { xyz: [0,0,0], rpy:[0,0,0] },
        geometry : { mesh : { filename : "eyes.STL" } },
	material : { color : {
	    rgba : [.9, .9, .9, 1]
	  }
	}
      }
    },
  },
}

robot.endeffector = {};
robot.endeffector.frame = "wrist_R";
robot.endeffector.position = [ [0],[0],[.5],[1] ]


robot.joints = {};

robot.joints.head_revolve = {parent:"body", child:"neck"};
robot.joints.head_revolve.origin = {xyz: [0.2,.8,.4], rpy:[0,0,0]};
robot.joints.head_revolve.axis = [0,1,0];

robot.joints.head_tilt = {parent:"neck", child:"eyes"};
robot.joints.head_tilt.origin = {xyz: [-0.1,0.25,-0.36], rpy:[0,0,0]};
robot.joints.head_tilt.axis = [1,0,0];

robot.joints.shoulder_L = {parent:"body", child:"arm_L"};
robot.joints.shoulder_L.origin = {xyz: [-0.4,0.5,0.75], rpy:[0,0,0]};
robot.joints.shoulder_L.axis = [0,0,1];

robot.joints.shoulder_R = {parent:"body", child:"arm_R"};
robot.joints.shoulder_R.origin = {xyz: [-0.4,0.5,-0.1], rpy:[0,0,0]};
robot.joints.shoulder_R.axis = [0,0,1];

robot.joints.hip_L = {parent:"body", child:"foot_L"};
robot.joints.hip_L.origin = {xyz: [-0.3,0,0.76], rpy:[0,0,0]};
robot.joints.hip_L.axis = [0,0,1];

robot.joints.hip_R = {parent:"body", child:"foot_R"};
robot.joints.hip_R.origin = {xyz: [-0.3,0,-0.2], rpy:[0,0,0]};
robot.joints.hip_R.axis = [0,0,1];

robot.joints.wrist_L = {parent:"arm_L", child:"hand_L"};
robot.joints.wrist_L.origin = {xyz: [-0.3,0.2,0.08], rpy:[3.1416,0,0]};
robot.joints.wrist_L.axis = [0,1,0];

robot.joints.wrist_R = {parent:"arm_R", child:"hand_R"};
robot.joints.wrist_R.origin = {xyz: [-0.3,0,0], rpy:[0,0,0]};
robot.joints.wrist_R.axis = [0,1,0];


robot.links_geom_imported = true;

links_geom = {};

progressLinkLoading = 0;
i = 0;
imax = Object.keys(robot.links).length;
for (x in robot.links) {
  filename_split = robot.links[x].visual.geometry.mesh.filename.split('.');
  geom_index = filename_split[0];
  geom_extension = filename_split[filename_split.length-1];
  console.log(geom_index + "  " + geom_extension);
  if(geom_extension === "STL") {
  assignFetchModelSTL('./robots/walle/meshes/'+robot.links[x].visual.geometry.mesh.filename,robot.links[x].visual.material,x);
  }
  i++;
  progressLinkLoading = i/imax;
  console.log("Robot geometry: progressLinkLoading " + progressLinkLoading*100);
}

function assignFetchModelSTL(filename,material_urdf,linkname) {
    console.log("assignFetchModel : "+filename+" - "+linkname); 
    var stl_loader = new THREE.STLLoader();
    var val = stl_loader.load(filename, 
       function ( geometry ) {
            var material_color = new THREE.Color(material_urdf.color.rgba[0], material_urdf.color.rgba[1], material_urdf.color.rgba[2]);
            var material = new THREE.MeshLambertMaterial( {color: material_color, side: THREE.DoubleSide} );
            links_geom[linkname] = new THREE.Mesh( geometry, material ) ;
        }
    );
}


  filename_split = robot.links[x].visual.geometry.mesh.filename.split('.');
  geom_index = filename_split[0];
  geom_extension = filename_split[filename_split.length-1];
  console.log(geom_index + "  " + geom_extension);
