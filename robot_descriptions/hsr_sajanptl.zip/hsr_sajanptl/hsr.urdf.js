
/*
     Toyota HSR (Human Support Robot) URDF kinematic description in JavaScript
     via Toyota Reseach Institute (TRI)     
 
     @author Sajan Patel (sajanptl@umich.edu)  
     @author ohseejay / https://github.com/ohseejay / https://bitbucket.org/ohseejay

    Obtained from the ROS-Kinetic hsrb_description package from Toyota Motor Company
    (through TRI).
*/

robot = {
  name: "hsr", 
  base: "base_link", 
  origin:{ xyz: [-0.025978, -0.005498, 0.17633], rpy:[0,0,0] },
  links: {
    "base_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/base_v2/base_light.dae" } }
      }
    },
    "base_roll_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "" } }
      }
    },
    "base_r_drive_wheel_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "" } }
      }
    },
    "base_l_drive_wheel_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : ""} }
      }
    },
    "torso_lift_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/torso_v0/torso_light.dae" } }
      }
    },
    "head_pan_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/head_v1/head_pan.dae" } }
      }
    },
    "head_tilt_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/head_v1/head_tilt.dae" } }
      }
    },
    "arm_lift_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/arm_v0/shoulder.dae" } }
      }
    },
    "arm_flex_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/arm_v0/arm_flex_light.dae" } }
      }
    },
    "arm_roll_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/arm_v0/arm_roll_light.dae" } }
      }
    },
    "wrist_flex_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/wrist_v0/wrist_flex.dae" } }
      }
    },
    "wrist_ft_sensor_mount_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "" } }
      }
    },
    "wrist_ft_sensor_frame": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "" } }
      }
    },
    "wrist_roll_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/wrist_v0/wrist_roll.dae" } }
      }
    },
    "hand_palm_link": {
      visual : { 
        origin : { xyz: [0, 0, 0], rpy:[0, 0, 0] },
        geometry : { mesh : { filename : "meshes/hand_v0/palm_light.dae" } }
      }
    },
  },
};

// specify name of endeffector frame
robot.endeffector = {};
robot.endeffector.frame = "hand_palm_joint";
robot.endeffector.position = [ [0.1],[0],[0],[1] ];

// JOINTS
robot.joints = {};

robot.joints.torso_lift_joint = {parent:"base_link", child:"torso_lift_link"};
robot.joints.torso_lift_joint.axis = [0, 0, 1];
robot.joints.torso_lift_joint.type = "prismatic";
robot.joints.torso_lift_joint.origin = {xyz: [-0.051142, 0.003454, 0.752], rpy:[0,0,0]};
robot.joints.torso_lift_joint.limit = {lower:0, upper:0.345};

robot.joints.base_roll_joint = {parent:"base_link", child:"base_roll_link"};
robot.joints.base_roll_joint.axis = [0, 0, 1];
robot.joints.base_roll_joint.type = "continuous";
robot.joints.base_roll_joint.origin = {xyz: [-0.01948200, 0.00219100, 0.07101300], rpy:[0,0,0]};

robot.joints.base_r_drive_wheel_joint = {parent:"base_roll_link", child:"base_r_drive_wheel_link"};
robot.joints.base_r_drive_wheel_joint.axis = [0, 1, 0];
robot.joints.base_r_drive_wheel_joint.type = "continuous";
robot.joints.base_r_drive_wheel_joint.origin = {xyz: [-0.11, -0.133, 0.04], rpy:[0, 0, 0]};

robot.joints.base_l_drive_wheel_joint = {parent:"base_roll_link", child:"base_l_drive_wheel_link"};
robot.joints.base_l_drive_wheel_joint.axis = [0, 1, 0];
robot.joints.base_l_drive_wheel_joint.type = "continuous";
robot.joints.base_l_drive_wheel_joint.origin = {xyz: [-0.11, 0.133, 0.04], rpy:[0, 0, 0]};

robot.joints.head_pan_joint = {parent:"torso_lift_link", child:"head_pan_link"};
robot.joints.head_pan_joint.axis = [0, 0, 1];
robot.joints.head_pan_joint.type = "revolute";
robot.joints.head_pan_joint.origin = {xyz: [0.001724, -0.001969, -0.028886], rpy:[0,0,0]};
robot.joints.head_pan_joint.limit = {lower: -3.84, upper: 1.75};

robot.joints.head_tilt_joint = {parent:"head_pan_link", child:"head_tilt_link"};
robot.joints.head_tilt_joint.axis = [0, -1, 0];
robot.joints.head_tilt_joint.type = "revolute";
robot.joints.head_tilt_joint.origin = {xyz: [-0.0355376, -0.002436, 0.117733], rpy:[0,0,0]};
robot.joints.head_tilt_joint.limit = {lower: -3.84, upper: 1.75};

robot.joints.arm_lift_joint = {parent:"base_link", child:"arm_lift_link"};
robot.joints.arm_lift_joint.axis = [0,0,1];
robot.joints.arm_lift_joint.type = "revolute";
robot.joints.arm_lift_joint.origin = {xyz: [0.051549, 0.042438, -0.064145 + 0.064145 + 0.340], rpy:[0,0,0]};
robot.joints.arm_lift_joint.limit = {lower:0, upper:0.69};

robot.joints.arm_flex_joint = {parent:"arm_lift_link", child:"arm_flex_link"};
robot.joints.arm_flex_joint.axis = [0, -1, 0];
robot.joints.arm_flex_joint.type = "revolute";
robot.joints.arm_flex_joint.origin = {xyz: [0.141 + 0.000632, 0.078 + 0.006404, 0.118529], rpy:[0,0,0]};
robot.joints.arm_flex_joint.limit = {lower: -2.62, upper: 0};

robot.joints.arm_roll_joint = {parent:"arm_flex_link", child:"arm_roll_link"};
robot.joints.arm_roll_joint.axis = [0, 0, 1];
robot.joints.arm_roll_joint.type = "revolute";
robot.joints.arm_roll_joint.origin = {xyz: [-0.006927 + 0.0005, 0.002039, -0.064837 + 0.345], rpy:[0,0,0]};
robot.joints.arm_roll_joint.limit = {lower: -2.09, upper: 3.84};

robot.joints.wrist_flex_joint = {parent:"arm_roll_link", child:"wrist_flex_link"};
robot.joints.wrist_flex_joint.axis = [0, -1, 0];
robot.joints.wrist_flex_joint.type = "revolute";
robot.joints.wrist_flex_joint.origin = {xyz: [0.000131, -0.003929, 0.00217], rpy:[0,0,0]};
robot.joints.wrist_flex_joint.limit = {lower: -1.92, upper: 1.22};

robot.joints.wrist_roll_joint = {parent:"wrist_flex_link", child:"wrist_ft_sensor_mount_link"};
robot.joints.wrist_roll_joint.axis = [0, 0, 1];
robot.joints.wrist_roll_joint.type = "revolute";
robot.joints.wrist_roll_joint.origin = {xyz: [-0.00,0,0], rpy:[0,0,0]};
robot.joints.wrist_flex_joint.limit = {lower: -1.92, upper: 3.67};

robot.joints.wrist_ft_sensor_frame_joint = {parent:"wrist_ft_sensor_mount_link", child:"wrist_ft_sensor_frame"};
robot.joints.wrist_ft_sensor_frame_joint.axis = [0, 0, 1];
robot.joints.wrist_ft_sensor_frame_joint.type = "revolute";
robot.joints.wrist_ft_sensor_frame_joint.origin = {xyz: [0,0, 0.0735], rpy:[-3.14159265359,0,0]};
robot.joints.wrist_ft_sensor_frame_joint.limit = {lower: 0, upper: 0};

robot.joints.wrist_ft_sensor_frame_inverse_joint = {parent:"wrist_ft_sensor_frame", child:"wrist_roll_link"};
robot.joints.wrist_ft_sensor_frame_inverse_joint.axis = [0, 0, 1];
robot.joints.wrist_ft_sensor_frame_inverse_joint.type = "fixed";
robot.joints.wrist_ft_sensor_frame_inverse_joint.origin = {xyz: [0,0, 0.0735], rpy:[-3.14159265359,0,0]};

robot.joints.hand_palm_joint = {parent:"wrist_roll_link", child:"hand_palm_link"};
robot.joints.hand_palm_joint.axis = [0, 0, 1];
robot.joints.hand_palm_joint.type = "fixed";
robot.joints.hand_palm_joint.origin = {xyz: [0.012, 0.0, 0.1405], rpy:[0, 0, 3.14159265359]};

// note ROS coordinate system (x:forward, y:lateral, z:up) is different than threejs (x:lateral, y:up, z:forward)
robot.links_geom_imported = true;

links_geom = {};
links_geom['base_roll_link'] = new THREE.CubeGeometry(0.1, 0.1, 0.1);
links_geom['base_roll_link'].applyMatrix( new THREE.Matrix4().makeTranslation(0, 0, 0) );

links_geom['base_r_drive_wheel_link'] = new THREE.CubeGeometry(0.1, 0.1, 0.1);
links_geom['base_r_drive_wheel_link'].applyMatrix( new THREE.Matrix4().makeTranslation(0, 0, 0) );

links_geom['base_l_drive_wheel_link'] = new THREE.CubeGeometry(0.1, 0.1, 0.1);
links_geom['base_l_drive_wheel_link'].applyMatrix( new THREE.Matrix4().makeTranslation(0, 0, 0) );

links_geom['wrist_ft_sensor_mount_link'] = new THREE.CubeGeometry(0.1, 0.1, 0.1);
links_geom['wrist_ft_sensor_mount_link'].applyMatrix( new THREE.Matrix4().makeTranslation(0, 0, 0) );

links_geom['wrist_ft_sensor_frame'] = new THREE.CubeGeometry(0.1, 0.1, 0.1);
links_geom['wrist_ft_sensor_frame'].applyMatrix( new THREE.Matrix4().makeTranslation(0, 0, 0) );

var tmp_robot_material = new THREE.MeshLambertMaterial( { color: 0x00234c, transparent: true, opacity: 0.9 } );
var special_links = ['base_roll_link', 
                     'base_r_drive_wheel_link', 
                     'base_l_drive_wheel_link',
                     'wrist_ft_sensor_frame',
                     'wrist_ft_sensor_mount_link'];
for (i in special_links) {
    var x = special_links[i];
    links_geom[x] = new THREE.Mesh(links_geom[x], tmp_robot_material);
}

progressLinkLoading = 0;
i = 0;
keys = Object.keys(robot.links);
imax = keys.length;
console.log(keys);
for (i in keys) {
  var x = keys[i];
  console.log('Now at ' + x);
  var fname = robot.links[x].visual.geometry.mesh.filename;
  if (fname !== "") {  
      filename_split = robot.links[x].visual.geometry.mesh.filename.split('.');
      geom_index = filename_split[0];
      geom_extension = filename_split[filename_split.length-1];
      console.log(geom_index + "  " + geom_extension);
      
      if (geom_extension === "dae") { // KE: extend to use regex
        assignHSRModelCollada('./robots/hsr/'+robot.links[x].visual.geometry.mesh.filename,x);
      }
      else if (geom_extension === "DAE") { // extend to use regex
        assignHSRModelCollada('./robots/hsr/'+robot.links[x].visual.geometry.mesh.filename,x);
      }
      else {
        assignHSRModelSTL('./robots/hsr/'+robot.links[x].visual.geometry.mesh.filename,robot.links[x].visual.material,x);
      }
  }
  i++;
  progressLinkLoading = i / imax; 
  console.log("Robot geometry: progressLinkLoading " + progressLinkLoading*100);
}

function assignHSRModelCollada(filename,index) {

    console.log("assignHSRModel : "+filename+" - "+index); 
    var collada_loader = new THREE.ColladaLoader();
    var val = collada_loader.load(filename, 
       function ( collada ) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename+" - "+index+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        },
        function (xhr) {
            console.log(filename+" - "+index+": "+ xhr + ' error' );
        }
    );
}

function assignHSRCollada2(filename, index) {

    console.log("assignHSRModel : " + filename + " - "+index); 
    var collada_loader = new ColladaLoader2();
    var val = collada_loader.load(filename, 
       function ( collada ) {
            links_geom[index] = collada.scene;
        },
        function (xhr) {
            console.log(filename+" - "+index+": "+(xhr.loaded / xhr.total * 100) + '% loaded' );
        }
    );
}


function assignHSRModelSTL(filename, material_urdf, linkname) {

    console.log("assignHSRModel : " + filename +" - "+ linkname); 
    var stl_loader = new THREE.STLLoader();
    var val = stl_loader.load(filename, 
       function ( geometry ) {
            // ocj: add transparency
            var material_color = new THREE.Color(material_urdf.color.rgba[0], material_urdf.color.rgba[1], material_urdf.color.rgba[2]);
            var material = new THREE.MeshLambertMaterial( {color: material_color, side: THREE.DoubleSide} );
            links_geom[linkname] = new THREE.Mesh( geometry, material ) ;
        },
        function (xhr) {
            console.log(filename+" - "+linkname+": "+(xhr.loaded / xhr.total * 100) + '% loaded');
        }
    );
}




